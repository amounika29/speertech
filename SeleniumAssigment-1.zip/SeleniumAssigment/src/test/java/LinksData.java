import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class LinksData {
    public static WebDriver webDriver;

    public static void main(String a[]) throws IOException {
        LinksData linksData = new LinksData();
        linksData.runLinks();
        System.exit(0);
    }

    public void runLinks() throws IOException {
        System.out.println("inside runlinks");
        WebDriverManager.chromedriver().setup();
        webDriver = new ChromeDriver();
        BufferedReader no = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Please no of links :: ");
        int noOfLinks = Integer.parseInt(no.readLine());
        System.out.println("Please Enter the links :: ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        for (int i = 1; i <= noOfLinks; i++) {
            List<String> linkToClick;
            linkToClick = Collections.singletonList(br.readLine());
            Iterator iterator = linkToClick.listIterator();
            while (iterator.hasNext()) {
                webDriver.get(String.valueOf(iterator.next()));
                webDriver.navigate().refresh();
                if (webDriver.getTitle().contains("Wikipedia")) {
                    List<WebElement> validWikiLinks = webDriver.findElements(By.xpath("//*[contains(@href,'wiki')]"));
                    System.out.println("no of embedded wikilinks::" + validWikiLinks.size());
                } else {
                    System.out.println("Not a valid Wikipedia link.. Please enter new link");
                }
            }
        }
        webDriver.close();
    }
}