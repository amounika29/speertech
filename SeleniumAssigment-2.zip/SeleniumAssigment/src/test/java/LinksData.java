import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class LinksData {
    public static WebDriver webDriver;

    public static void main(String a[]) throws IOException {
        LinksData linksData = new LinksData();
        linksData.runLinks();

    }

    public void runLinks() throws IOException {
        try {
            WebDriverManager.chromedriver().setup();
            webDriver = new ChromeDriver();
            BufferedReader no = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Please no of links :: ");
            int noOfLinks = no.read();
            System.out.println("Please Enter the links :: ");
            for (int i = 1; i < noOfLinks; i++) {
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                List<String> linkToClick;
                linkToClick = Collections.singletonList(br.readLine());
                webDriver.get(linkToClick.iterator().next());
                webDriver.navigate().refresh();
                if (webDriver.getTitle().contains("Wikipedia")) {
                    List<String> validWikiLinks = Collections.singletonList(webDriver.getCurrentUrl());
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}